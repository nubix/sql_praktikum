README

Everything is to has be executed from the current directory



AufgabeA
===================
Compile with:
javac sqllab/AufgabeA.java      

Execute with:
java -cp .:lib/db2jcc4.jar sqllab.AufgabeA 



AufgabeB
===================
Compile with:
javac sqllab/AufgabeB.java      

Execute with:
java -cp .:lib/db2jcc4.jar sqllab.AufgabeB 

